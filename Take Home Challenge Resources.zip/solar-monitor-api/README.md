## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Project setup

```bash
$ npm install
```

## Compile and run the project

```bash
# development
$ npm run dev

# watch mode
$ npm run dev
```

## Run with Docker

```bash
$ docker build -t solar-monitor-api .
$ docker run -p 3000:3000 solar-monitor-api
```