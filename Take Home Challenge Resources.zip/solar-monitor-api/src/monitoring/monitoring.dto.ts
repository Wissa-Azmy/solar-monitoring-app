import { ApiProperty } from '@nestjs/swagger';

export class MonitoringDataDto {
  @ApiProperty({ description: 'Timestamp of the data point', example: '2024-10-28T00:05:00.000Z' })
  timestamp: Date;

  @ApiProperty({ description: 'Value at the given timestamp in watts', example: 1500 })
  value: number;
}
