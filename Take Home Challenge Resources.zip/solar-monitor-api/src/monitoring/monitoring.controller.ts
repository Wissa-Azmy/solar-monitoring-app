import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { MonitoringService } from './monitoring.service';
import { MonitoringDataDto } from './monitoring.dto';

@ApiTags('monitoring')
@Controller('monitoring')
export class MonitoringController {
  constructor(private readonly monitoringService: MonitoringService) {}

  @Get()
  @ApiOperation({ summary: 'Get aggregated monitoring data' })
  @ApiQuery({ name: 'date', type: String, description: 'Date to fetch data for (YYYY-MM-DD)' })
  @ApiQuery({ name: 'type', type: String, description: 'Type of data (e.g., solar, house, battery)' })
  async getMonitoringData(
    @Query('date') date: string,
    @Query('type') type: string,
  ): Promise<MonitoringDataDto[]> {
    if (!date || !type) {
      throw new Error('Date and type query parameters are required.');
    }
    return this.monitoringService.getAggregatedData(date, type);
  }
}

