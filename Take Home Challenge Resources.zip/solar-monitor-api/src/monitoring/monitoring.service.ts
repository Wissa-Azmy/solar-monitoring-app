import { Injectable } from '@nestjs/common';

@Injectable()
export class MonitoringService {
  async getAggregatedData(date: string, type: string): Promise<any[]> {
    const startTime = new Date(date);
    const endTime = new Date(startTime);
    endTime.setDate(startTime.getDate() + 1);

    // Generate random data for each 5-minute interval within the 24-hour period
    const aggregatedData = this.generateRandomDataIn5MinIntervals(startTime, endTime);

    return aggregatedData;
  }

  private generateRandomDataIn5MinIntervals(start: Date, end: Date): any[] {
    const interval = 5 * 60 * 1000; // 5 minutes in milliseconds
    const dataPoints = [];

    for (let currentTime = start.getTime(); currentTime < end.getTime(); currentTime += interval) {
      const timestamp = new Date(currentTime);
      const randomValue = this.getRandomValueForType(); // Generate a random value

      dataPoints.push({ timestamp, value: randomValue });
    }

    return dataPoints;
  }

  private getRandomValueForType(): number {
    // Generate a random value; adjust the range based on type if needed
    return Math.floor(Math.random() * (9000 - 1000 + 1) + 1000); // Random value between 1000 and 9000
  }
}
